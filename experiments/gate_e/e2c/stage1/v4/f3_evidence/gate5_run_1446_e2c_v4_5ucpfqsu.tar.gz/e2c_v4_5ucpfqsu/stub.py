import hashlib, json, os, random, shutil, sys, time
D = os.environ["STUB_DIR"]
kind, name = sys.argv[1], sys.argv[2]
def call(msg):
    with open(os.path.join(D, "calls.log"), "a") as f:
        f.write(msg + "\n")
call(f"start {kind} {name}")
if os.environ.get("STUB_FAIL_NAME") == f"{kind}:{name}":
    sys.exit(int(os.environ.get("STUB_FAIL_CODE", "1")))
def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path + ".stubtmp", "w").write(text)
    os.replace(path + ".stubtmp", path)
def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()
bad = os.environ.get("STUB_BAD", "")  # "run|field|json value"
extra = str(random.random()) if os.environ.get("STUB_NONDET_NAME") == name else ""
if kind == "train":
    cond, arm, s = name.split("_"); seed = int(s[1:]); lam = sys.argv[3] if len(sys.argv) > 3 else ""
    for t in (0, 25, 50, 75, 100, 150, 200, 300, 500, 1000, 2000, 3000, 6000, 12000):
        write(os.path.join(D, "runs", f"{name}_step{t}.pt"), f"ckpt {name} {t}{extra}")
    rec = {"cond": cond, "arm": arm, "seed": seed, "steps": 12000, "complete": True, "lam": float(lam) if lam else None,
           "init_param_sha256": f"init-{arm}-{seed}", "batch_chain": {"100": f"chain-{seed}"}, "first_batch_sha256": f"b-{seed}",
           "lr_schedule_sha256": "lr", "optimizer": {"type": "AdamW"}, "clip": 1.0, "batch_size": 64,
           "r_u": [0.1, 0.2], "kappa_u": [1.0, 0.5], "loss_every_step": [3.0, 2.9], "aux_loss_every_step": [3.9, 3.8]}
    if cond != "C0":
        rec.update({"heads_sha256": {"p": f"heads-{arm}-{seed}"}, "record_points": ["p"], "positions": [2, 6], "mask": "m", "E_W": 1.0})
    if cond == "C2":
        rec["digit_code_sha256"] = os.environ["STUB_CODE_SHA_" + str(seed)]
    if extra:
        rec["r_u"] = [0.1, float(extra)]
    if bad and bad.split("|")[0] == name:
        rec[bad.split("|")[1]] = json.loads(bad.split("|")[2])
    write(os.path.join(D, "runs", f"{name}.json.progress.json"), json.dumps(dict(rec, complete=False)))
    time.sleep(float(os.environ.get("STUB_SLEEP_TRAIN", "0")))
    write(os.path.join(D, "runs", f"{name}.json"), json.dumps(rec))
    os.remove(os.path.join(D, "runs", f"{name}.json.progress.json"))
elif kind == "archive":
    os.makedirs(os.path.join(D, "remote"), exist_ok=True)
    for f in os.listdir(os.path.join(D, "runs")):
        if f.startswith(name + "_step") and f.endswith(".pt"):
            shutil.copyfile(os.path.join(D, "runs", f), os.path.join(D, "remote", f))
elif kind == "restore":
    local = sys.argv[3]
    if os.environ.get("STUB_RESTORE_FAIL") == "1":
        sys.exit(1)
    shutil.copyfile(os.path.join(D, "remote", os.path.basename(local)), local)
elif kind == "diag":
    time.sleep(float(os.environ.get("STUB_SLEEP_DIAG", "0")))
    st = name[5:]
    run, t = st.rsplit("_step", 1)
    cond, arm, s = run.split("_")
    r = {"arm": arm, "seed": int(s[1:]), "step": int(t), "param_sha256": sha(os.path.join(D, "runs", st + ".pt")),
         "seconds": {"M1": random.random()}, "M1": {"x": st + extra}, "M2": {}, "A_lin": 0.5, "M6": {},
         "M3": {"controls": {"negative_query_swap": {"pass": True}, "positive_own_letter_emb": {"pass": True}}},
         "M0": {"pass": True}}
    write(os.path.join(D, "results", st + ".json"), json.dumps(r))
elif kind == "keyspace":
    out = sys.argv[3]
    write(out, os.environ["STUB_KEYSPACE"])
elif kind == "test2":
    out = sys.argv[3]
    path = os.path.join(os.path.dirname(out), "test2_heldout.jsonl")
    write(path, "simulated test2 (no real key)\n")
    iso = json.loads(os.environ.get("STUB_ISOLATION", '{"keys_not_in_R_star": 0, "overlap_E1_sets": 0, "overlap_training_streams": 0}'))
    write(out, json.dumps({"sha256": sha(path), "isolation": iso, "stats": {"simulated": True}}))
elif kind == "judge":
    out = sys.argv[3]
    if os.path.exists(out):
        sys.exit(3)
    cond, arm, s = name.split("_")
    t2 = sha(os.path.join(D, "judgments", "test2_heldout.jsonl"))
    write(out, json.dumps({"cond": cond, "arm": arm, "seed": int(s[1:]), "set": "test2_heldout", "test2_sha256": t2, "main": {}}))
elif kind == "sync":
    pass
call(f"done {kind} {name}")
